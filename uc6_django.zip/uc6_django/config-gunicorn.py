import multiprocessing
import os
#bind - The socket to bind
bind = "10.132.0.27:8000" # Production
# bind = "10.164.0.10:8000" #Test
workers = multiprocessing.cpu_count() * 2 + 1
#For the eventlet and gevent worker classes this limits the maximum number of simultaneous clients that a single process can handle.
worker_connections = 1000
#If a worker does not notify the master process in this number of seconds it is killed and a new worker is spawned.       to replace it.
#for ML backend process not sure how long it will take so setting it to 1800 secs/30 minutes
timeout = 1800
#The number of seconds to wait for the next request on a Keep-Alive HTTP connection.
keepalive = 1800
#There are some Python libraries such as gevent and Asyncio that enable concurrency in Python by using “pseudo-threads” for co routines.
worker_class = 'gevent'
#maximum number of requests to handle from users.
max_requests = 1000
#This refers to the number of clients that can be waiting to be
#       served. Exceeding this number results in the client
#       getting an error when attempting to connect.
backlog = 2048

logfile = "/gunicorn.log"