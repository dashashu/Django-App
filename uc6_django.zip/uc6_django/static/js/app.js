
// const spinnerBox = document.getElementById('spinerBox')
// const dataBox = document.getElementById('dataBox')

// $(function() {
//     // selector has to be . for a class name and # for an ID
//     $('.execute').click(function(e) {
//         //e.preventDefault(); // prevent form from reloading page
//         alert("hiii");
//         $.ajax({
//             type: 'POST',
//             url: '/output/',
//             success: function(response){
//                 if(response.status == 1){
//                     window.location('/output.html')
//                 }else{
//                     alert(data.message)
//                         // do your redirect
//                         print('inside Ajax-')
//                         window.location('/home/')
//                 }
//                 setTimeout(()=>{
//                     spinnerBox.classList.add('not-visible')
//                     },500)
//             },
//             error: function(error){
//                 console.log(error)
//             }
//         });
//         });
//     });
// $('#myButton').click(function() {
//     var fieldValue = $('#myInputField').val();
//     doAjax(fieldValue);
// });
$(document).ready(
    function(){
        $('input:file').change(
            function(){
                if ($(this).val()) {
                    $('input:submit').attr('disabled',false); 
                } 
            }
            );
    });