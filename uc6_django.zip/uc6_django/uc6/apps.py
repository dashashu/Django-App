from django.apps import AppConfig


class Uc6Config(AppConfig):
    name = 'uc6'
