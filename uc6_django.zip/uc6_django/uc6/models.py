from typing import DefaultDict
import pandas as pd
from django.db import models
from django.contrib.auth.models import User
from pandas.core.frame import DataFrame
import math, json, os,io
from pandas.compat import StringIO
import numpy as np
import pickle, ast
from django.http import HttpResponse
import csv

class master_vbom(models.Model):
   opco_name = models.CharField(max_length = 50,blank= False, null= False)
   data_center = models.CharField(max_length = 50,blank= False, null= False)
   fy = models.IntegerField(blank= False, null= False,default= 0)
   cluster = models.CharField(max_length = 50,blank= False, null= False,default= 'unknown_cluster')

   req_type = models.CharField(max_length = 50, null= True)
   vnf_name = models.CharField(max_length = 50 , blank= True, null= True,default= 'unknown_vnf')
   vm_name = models.CharField(max_length = 50, blank= True, null= True,default= 'unknown_vm')
   site_name = models.CharField(max_length = 50, blank= True, null= True,default= 'unknown_site')
   nsx_t = models.CharField(max_length = 50, null= True)
   aff_intra = models.CharField(max_length = 50, null= True)
   aff_inter =models.CharField(max_length = 50, null= True)
   vertical_domain = models.CharField(max_length = 50, null= True)
   storage_size = models.CharField(max_length = 50,blank= True, null= True, default= 0)
   vnf_instance = models.IntegerField(blank= False, null= False,default= 0)
   vm_instance = models.IntegerField(blank= False, null= False,default= 0)
   numa = models.CharField(max_length = 50, null= True)
   socket = models.CharField(max_length = 50, null= True)
   vcpu = models.IntegerField(blank= False, null= False,default= 0)
   rxtx_cpu = models.CharField(max_length = 50, null= True)
   ram = models.IntegerField(blank= False, null= False,default= 0)
   storage_datadisk = models.IntegerField(blank= False, null= False,default= 0)
   storage_osdisk = models.IntegerField(blank= False, null= False,default= 0)
   storage_running = models.IntegerField(blank= False, null= False,default= 0)
   storage_loading = models.IntegerField(blank= False, null= False,default= 0)
   storage_rw = models.CharField(max_length = 50,blank= True, null= True,default= 'unknown')
   nw_bandwidth = models.IntegerField(blank= False, null= False,default= 0)
   ew_bandwidth = models.IntegerField(blank= False, null= False,default= 0)
   onboarding_date = models.CharField(max_length = 50, null= True)
   backup = models.CharField(max_length = 50, null= True)
   probing = models.CharField(max_length = 50, null= True)
class input_config(models.Model):
   spareNumber = models.IntegerField(blank= False, null= False,default= 0)
   extrasocketEnabled = models.BooleanField()
   vBomCustomer = models.BooleanField()
   esxiCores = models.IntegerField(blank= False, null= False,default= 0)
   txrxCores = models.IntegerField(blank= False, null= False,default= 0)
   defaultHighThroughput = models.IntegerField(blank= False, null= False,default= 0)
   defaultBlockSize = models.IntegerField(blank= False, null= False,default= 0)
   foundationFlag = models.BooleanField()
   managementFlag = models.BooleanField()
   affinityOnlyPerTypePerInstance = models.BooleanField()
   defaultFoundationSpace = models.IntegerField(blank= False, null= False,default= 0)
   defaultAvgBlockSize = models.IntegerField(blank= False, null= False,default= 0)
   defaultAvgReadWrite = models.IntegerField(blank= False, null= False,default= 0)
   defaultAvgIOPS = models.IntegerField(blank= False, null= False,default= 0)
   bladeBufferPercentage = models.IntegerField(blank= False, null= False,default= 0)
   storageBufferPercentage = models.IntegerField(blank= False, null= False,default= 0)
   IOPSBufferPercentage = models.IntegerField(blank= False, null= False,default= 0)
   NSBWBufferPercentage = models.IntegerField(blank= False, null= False,default= 0)
   #catalogChoices
   blade = models.IntegerField(blank= False, null= False,default= 0)
   highPerformanceBlade = models.IntegerField(blank= False, null= False,default= 0)
   enclosure = models.IntegerField(blank= False, null= False,default= 0)
   highPerformanceEnclosure = models.IntegerField(blank= False, null= False,default= 0)
   SynSigBlade = models.IntegerField(blank= False, null= False,default= 0)
   SynMedBlade = models.IntegerField(blank= False, null= False,default= 0)
   SynDataBlade = models.IntegerField(blank= False, null= False,default= 0)
   c7KDellStdblade = models.IntegerField(blank= False, null= False,default= 0)
   c7kDellHighPerfBlade = models.IntegerField(blank= False, null= False,default= 0)
   SynSigEnclousre = models.IntegerField(blank= False, null= False,default= 0)
   SynMedEnclosure = models.IntegerField(blank= False, null= False,default= 0)
   synDataEnclosure = models.IntegerField(blank= False, null= False,default= 0)
   c7KDellStdEnclosure = models.IntegerField(blank= False, null= False,default= 0)
   c7kDellHighPerfEnclosure = models.IntegerField(blank= False, null= False,default= 0)
   threePar = models.IntegerField(blank= False, null= False,default= 0)
   sanSwitchExpansion = models.IntegerField(blank= False, null= False,default= 0)
   sanSwitch = models.IntegerField(blank= False, null= False,default= 0)
   #clusterConfiguration
   sheetLabel = models.CharField(max_length = 50,blank= False, null= False)
   cpuOverProvisioning = models.IntegerField(blank= False, null= False,default= 0)
   ramOverProvisioning = models.IntegerField(blank= False, null= False,default= 0)
   storageReservation = models.IntegerField(blank= False, null= False,default= 0)
   maxThroughputPerBladeOverprovisioning = models.IntegerField(blank= False, null= False,default= 0)
   maxRunningIOPSPerBladeOverprovisioning = models.IntegerField(blank= False, null= False,default= 0)
   bladeFlag = models.CharField(max_length = 50,blank= False, null= False)
   enclosureFlag = models.CharField(max_length = 50,blank= False, null= False)
   probing = models.BooleanField()
class catalog(models.Model):
   hw_type = models.CharField(max_length = 50,blank= False, null= False)
   type = models.CharField(max_length = 50,blank= False, null= False)
   vendor = models.CharField(max_length = 50,blank= False, null= False)
   ac_dc = models.CharField(max_length = 50,blank= False, null= False)
   com_id = models.IntegerField(blank= False, null= False,default= 0)
   com_desc = models.CharField(max_length = 100,blank= False, null= False)
   ref_type = models.CharField(max_length = 50,blank= False, null= False)
   unit = models.IntegerField(blank= False, null= True,default= 0)
   default_value = models.IntegerField(blank= False, null= True,default= 0)
   initiative = models.CharField(max_length = 50,blank= False, null= False)
   capex_vpc = models.IntegerField(blank= False,   null= True,default= 0)
   opex_3yr = models.IntegerField(blank= False,   null= True,default= 0)
   opex_2yr = models.IntegerField(blank= False,   null= True,default= 0)
   no_core = models.IntegerField(blank= False,   null= True,default= 0)
   no_socket = models.IntegerField(blank= False,   null= True,default= 0)
   ram = models.IntegerField(blank= False,   null= True,default= 0)
   max_throughput = models.IntegerField(blank= False,   null= True,default= 0)
   max_running = models.IntegerField(blank= False,   null= True,default= 0)
   #container
   max_unit = models.IntegerField(blank= False,   null= True,default= 0)
   no_link = models.IntegerField(blank= False,   null= True,default= 0)
   #sorage
   no_node = models.IntegerField(blank= False,   null= True,default= 0)
   max_enclosure = models.IntegerField(blank= False,   null= True,default= 0)
   max_expansion = models.IntegerField(blank= False,   null= True,default= 0)
   threepar_ref = models.IntegerField(blank= False,   null= True,default= 0)
   disk_type = models.IntegerField(blank= False,   null= True,default= 0)
   usable_disk_cap = models.IntegerField(blank= False,   null= True,default= 0)
   raw_disk_cap = models.IntegerField(blank= False,   null= True,default= 0)
   no_disk_block = models.IntegerField(blank= False,   null= True,default= 0)
   no_link_enclosure = models.IntegerField(blank= False,   null= True,default= 0)
   max_disk_housed = models.IntegerField(blank= False, null= False,default= 0)

class output(models.Model):
   opco_name = models.CharField(max_length = 50,blank= False, null= False)
   data_center = models.CharField(max_length = 50,blank= False, null= False)
   user = models.CharField(max_length = 50,blank= False, null= False)
   sheet = models.TextField()

   def __str__(self):
      return self.sheet


"""......Extra  defination to support the model and its transaction fuctions 
master_vbom_update_create() will update the master_vbom table in uc6_database
catalog_update_create() wil update the catalog file table in uc6_databse
three_par_update_create()  will update the 3par table in uc6_database........"""


def master_vbom_update_create(request,full_file):
   '''create a new entry for uc6_master_vbom table'''
   opco = 'op'#request.POST['opco']
   datacenter = 'dc'#request.POST['datacenter']
   
   '''reading data from the uploaded excel file and gui form
   when the interactive GUI will be developed '''
   multi_sheet_file = pd.ExcelFile(full_file)
   
   excel_sheet_names = multi_sheet_file.sheet_names
   final_df = pd.DataFrame()
   total_yrs = 0
   for cluster in excel_sheet_names:
      colomn_start_yr = 9  # cmmon vbom columns
      column_end_yr = 9+17  # comon + FY vbom columns
      #break the df columns into one table
      df_org = pd.read_excel(multi_sheet_file, sheet_name=cluster, skiprows=2)
      enter_yrs = int((len(df_org.columns)-9)/17)
      df_common = df_org.iloc[:,0:9] #common coluns
      new_columns = df_common.columns
      new_columns = [item.replace("\n", "").replace(" ", "").split(".")[0] for item in new_columns]
      df_common.columns =new_columns
      df_common['key'] = 'x'
      for i in range(0, enter_yrs):
         df = df_org.iloc[:, colomn_start_yr:column_end_yr] #yearly columns
         new_columns = df.columns
         new_columns = [item.replace("\n", "").replace(" ", "").split(".")[0] for item in new_columns]
         df.columns =new_columns
         if not df.iloc[:, 0].isnull().all():
            df_slice_final = pd.concat([df_common, df], axis=1).reset_index() #creating a yr df
            df_slice_final['cluster'] = cluster
            df_slice_final['FY'] = i
            print(df_slice_final.shape)
            final_df = final_df.append(df_slice_final)
         column_end_yr = column_end_yr+17
         colomn_start_yr = colomn_start_yr+17
   #reindexing df
   final_df=final_df.reset_index(drop=True) 
   final_df.to_csv('database_entry.csv')
   for row in final_df.index:
      master = master_vbom.objects.update_or_create(opco_name= opco,
      data_center = datacenter,
      fy = int(final_df.loc[final_df.index[row], 'FY']),
      cluster = final_df.loc[final_df.index[row], 'cluster'],

      req_type = final_df.loc[final_df.index[row], 'Requesttype'],
      vnf_name = final_df.loc[final_df.index[row], 'VNFName'],
      vm_name = final_df.loc[final_df.index[row], 'VMTypeName'],
      site_name = final_df.loc[final_df.index[row], 'Sitename'],
      nsx_t = final_df.loc[final_df.index[row], 'NSX-T'],
      aff_intra = final_df.loc[final_df.index[row], "AFFINITYRULES-'INTRAVMType'"],
      aff_inter = final_df.loc[final_df.index[row], "AFFINITYRULES-'INTERVMType'"],
      vertical_domain = final_df.loc[final_df.index[row], 'Verticaldomainowner'],
      storage_size = final_df.loc[final_df.index[row], 'StorageBlockSize'],
      vnf_instance = int(final_df.loc[final_df.index[row], 'NumberofVNFinstances']),
      vm_instance = int(final_df.loc[final_df.index[row], 'NumberofVMspertype']),
      numa = final_df.loc[final_df.index[row], 'NUMA'],
      socket = final_df.loc[final_df.index[row], 'Socket'],
      vcpu = int(final_df.loc[final_df.index[row], 'NumberofvCPUperVM']),
      rxtx_cpu = final_df.loc[final_df.index[row], "RX/TX'CPUINCLUDEDINvCPUCount"],
      ram = int(final_df.loc[final_df.index[row], 'RAM(GB)perVM']),
      storage_datadisk = final_df.loc[final_df.index[row],'Storage(GB)perVM-DataDisk'],
      storage_osdisk = int(final_df.loc[final_df.index[row], 'Storage(GB)perVM-OSdisk']), 
      storage_running = int(final_df.loc[final_df.index[row], 'StorageIOPSperVM-Running']),
      storage_loading = int(final_df.loc[final_df.index[row], 'StorageIOPSperVM-Loading']),
      storage_rw = final_df.loc[final_df.index[row], 'StorageRead/WriteVMworkloaddistribution(%/%)'],
      nw_bandwidth = int(final_df.loc[final_df.index[row], 'North/SouthbandwidthrequirementperVM(Mbit/s)']),
      ew_bandwidth = int(final_df.loc[final_df.index[row], 'East/WestbandwidthrequirementperVM(Mbit/s)']),
      onboarding_date = final_df.loc[final_df.index[row], 'OnboardingDate/Otherrequirements'],
      backup = final_df.loc[final_df.index[row], 'Backuprequired'],
      probing = final_df.loc[final_df.index[row], 'Probingrequired']
      #,user = '' 
      )
   #master.save()

def catalog_update_create(full_file):
   #multi_sheet_file = pd.ExcelFile(request.FILES['document'])
   multi_sheet_file = pd.ExcelFile(full_file)
   excel_sheet_names = multi_sheet_file.sheet_names
   #final_df = pd.DataFrame()
   for cluster in excel_sheet_names: 
      no_core = 0
      no_socket = 0 
      ram =  0
      max_throughput = 0
      max_running = 0
      #container specific
      max_unit = 0
      no_link = 0
      #storage specific
      no_node = 0
      max_enclosure = 0
      max_expansion = 0
      threepar_ref = 0
      disk_type = 0
      usable_disk_cap = 0
      raw_disk_cap = 0
      no_disk_block = 0
      no_link_enclosure = 0
      max_disk_housed = 0 
      cols = [i for i in range(23) ]
      df_org = pd.read_excel(multi_sheet_file, sheet_name=cluster, skiprows=2,usecols=cols)
      new_columns = df_org.columns
      new_columns = [item.replace("\n", "").replace(" ", "").split(".")[0] for item in new_columns]
      df_org.columns =new_columns

      df = df_org.dropna(axis=0, subset=['Type']).reset_index(drop=True)
      print('df',df)
      for row in df.index:
         print('row',row)
      #drop the unnecessary rows 
         if cluster == 'Compute':
            no_core = no_core if math.isnan(df.loc[df.index[row], 'NumberofCoreperSocket']) else df.loc[df.index[row], 'NumberofCoreperSocket']
            no_socket = no_socket if math.isnan(df.loc[df.index[row], 'NumberofSocket']) else df.loc[df.index[row], 'NumberofSocket']
            ram = ram if math.isnan(df.loc[df.index[row], 'RAMGB']) else df.loc[df.index[row], 'RAMGB']
            max_throughput = max_throughput if math.isnan(df.loc[df.index[row], 'MaxThroughput(MBPS)']) else df.loc[df.index[row], 'MaxThroughput(MBPS)']
            max_running = max_running if math.isnan(df.loc[df.index[row], 'MaxRunningIOPS'])  else df.loc[df.index[row], 'MaxRunningIOPS']
         if cluster == 'Container':
            #container specific
            max_unit = max_unit if math.isnan(df.loc[df.index[row], 'Maxnumberofunitshoused'])  else df.loc[df.index[row], 'Maxnumberofunitshoused']
            no_link = no_link if math.isnan(df.loc[df.index[row], 'NumberofLinkUsedtowardseachSANSWITCH'])  else df.loc[df.index[row], 'NumberofLinkUsedtowardseachSANSWITCH']
         elif cluster == 'Storage':
            #sorage specific   
            no_node = no_node if math.isnan(df.loc[df.index[row], 'NumberOfNode'])  else df.loc[df.index[row], 'NumberOfNode']
            max_enclosure = max_enclosure if math.isnan(df.loc[df.index[row], 'MaxNumberofEnclosureSupported'])  else df.loc[df.index[row], 'MaxNumberofEnclosureSupported']
            max_expansion = max_expansion if math.isnan(df.loc[df.index[row], 'MaxNumberofExpansionsSupported'])  else df.loc[df.index[row], 'MaxNumberofExpansionsSupported']
            threepar_ref = threepar_ref if math.isnan(df.loc[df.index[row], '3PARReference'])  else df.loc[df.index[row], '3PARReference']
            disk_type = disk_type if math.isnan(df.loc[df.index[row], 'DiskType'])  else df.loc[df.index[row], 'DiskType']
            usable_disk_cap = usable_disk_cap if math.isnan(df.loc[df.index[row], 'UsableDiskCapacity']) else df.loc[df.index[row], 'UsableDiskCapacity']
            raw_disk_cap = raw_disk_cap if math.isnan(df.loc[df.index[row], 'RawDiskCapacity'])  else df.loc[df.index[row], 'RawDiskCapacity']
            no_disk_block = no_disk_block if math.isnan(df.loc[df.index[row], 'NumberofDisksforeachBlock'])  else df.loc[df.index[row], 'NumberofDisksforeachBlock']
            no_link_enclosure = no_link_enclosure if math.isnan(df.loc[df.index[row], 'NumberofLinkUsedtowardseachSANSWITCHforeachEnclosureconnected'])  else df.loc[df.index[row], 'NumberofLinkUsedtowardseachSANSWITCHforeachEnclosureconnected']
            max_disk_housed= max_disk_housed if math.isnan(df.loc[df.index[row], 'Maxnumberofdiskshoused'])  else df.loc[df.index[row], 'Maxnumberofdiskshoused']

         master = catalog.objects.update_or_create(
         hw_type = cluster,
         type = df.loc[df.index[row], 'Type'],
         vendor = df.loc[df.index[row], 'Vendor'],
         ac_dc = df.loc[df.index[row], 'AC/DC'],
         com_id = 0 if math.isnan(df.loc[df.index[row], 'ComponentID']) else df.loc[df.index[row], 'ComponentID'],
         com_desc = df.loc[df.index[row], 'Componentdescription'],
         ref_type = df.loc[df.index[row], 'ReferenceContainerType'],
         unit = 0 if math.isnan(df.loc[df.index[row], 'Numberofunitsoccupied']) else df.loc[df.index[row], 'Numberofunitsoccupied'],
         default_value = 0 if math.isnan(df.loc[df.index[row], 'DefaultValueforFoundation[0']) else df.loc[df.index[row], 'DefaultValueforFoundation[0'],
         initiative = df.loc[df.index[row], 'Initiative'],
         capex_vpc = 0 if math.isnan(df.loc[df.index[row], 'Capexvpc']) else df.loc[df.index[row], 'Capexvpc'],
         opex_3yr = 0 if math.isnan(df.loc[df.index[row], 'Opex3yearsmaintenance']) else df.loc[df.index[row], 'Opex3yearsmaintenance'],
         opex_2yr = 0 if math.isnan(df.loc[df.index[row], 'Opex2Yearaddmaintenance']) else df.loc[df.index[row], 'Opex2Yearaddmaintenance'],
         #Compute spesific
         no_core = no_core,
         no_socket = no_socket,
         ram = ram,
         max_throughput = max_throughput,
         max_running = max_running,
         #container spesific
         max_unit = max_unit,
         no_link = no_link,
         #storage spesific
         no_node = no_node,
         max_enclosure = max_enclosure,
         max_expansion = max_expansion,
         threepar_ref = threepar_ref,
         disk_type = disk_type,
         usable_disk_cap = usable_disk_cap,
         raw_disk_cap = raw_disk_cap,
         no_disk_block = no_disk_block,
         no_link_enclosure = no_link_enclosure,
         max_disk_housed = max_disk_housed
         )

def cluster_update_create(full_file):
   
   j = json.loads(open(full_file).read())
   catalogChoices = j['catalogChoices']
   blade =  catalogChoices['blade']
   highPerformanceBlade = catalogChoices['highPerformanceBlade']
   enclosure = catalogChoices['enclosure']
   highPerformanceEnclosure = catalogChoices['highPerformanceEnclosure']
   SynSigBlade = catalogChoices['SynSigBlade']
   SynMedBlade = catalogChoices['SynMedBlade']
   SynDataBlade = catalogChoices['SynDataBlade']
   c7KDellStdblade = catalogChoices['c7KDellStdblade']
   c7kDellHighPerfBlade = catalogChoices['c7kDellHighPerfBlade']
   SynSigEnclousre = catalogChoices['SynSigEnclousre']
   SynMedEnclosure = catalogChoices['SynMedEnclosure']
   synDataEnclosure = catalogChoices['synDataEnclosure']
   c7KDellStdEnclosure = catalogChoices['c7KDellStdEnclosure']
   c7kDellHighPerfEnclosure = catalogChoices['c7kDellHighPerfEnclosure']
   threePar = catalogChoices['threePar']
   sanSwitchExpansion = catalogChoices['sanSwitchExpansion']
   sanSwitch = catalogChoices['sanSwitch']
   for sheet in j['clusterConfiguration']:
      master = input_config.objects.update_or_create(
      
      #common parameter
      spareNumber	 = 	 j['spareNumber'],
      extrasocketEnabled	 = 	 j['extrasocketEnabled'],
      vBomCustomer	 = 	 j['vBomCustomer'],
      esxiCores	 = 	 j['esxiCores'],
      txrxCores	 = 	 j['txrxCores'],
      defaultHighThroughput	 = 	 j['defaultHighThroughput'],
      defaultBlockSize	 = 	 j['defaultBlockSize'],
      foundationFlag	 = 	 j['foundationFlag'],
      managementFlag	 = 	 j['managementFlag'],
      affinityOnlyPerTypePerInstance	 = 	 j['affinityOnlyPerTypePerInstance'],
      defaultFoundationSpace	 = 	 j['defaultFoundationSpace'],
      defaultAvgBlockSize	 = 	 j['defaultAvgBlockSize'],
      defaultAvgReadWrite	 = 	 j['defaultAvgReadWrite'],
      defaultAvgIOPS	 = 	 j['defaultAvgIOPS'],
      bladeBufferPercentage	 = 	 j['bladeBufferPercentage'],
      storageBufferPercentage	 = 	 j['storageBufferPercentage'],
      IOPSBufferPercentage	 = 	 j['IOPSBufferPercentage'],
      NSBWBufferPercentage	 = 	 j['NSBWBufferPercentage'],
      

      blade = blade , highPerformanceBlade = highPerformanceBlade , enclosure = enclosure , 
      highPerformanceEnclosure = highPerformanceEnclosure , SynSigBlade = SynSigBlade , SynMedBlade = SynMedBlade , SynDataBlade = SynDataBlade , 
      c7KDellStdblade = c7KDellStdblade , c7kDellHighPerfBlade = c7kDellHighPerfBlade , SynSigEnclousre = SynSigEnclousre , 
      SynMedEnclosure = SynMedEnclosure , synDataEnclosure = synDataEnclosure , c7KDellStdEnclosure = c7KDellStdEnclosure , 
      c7kDellHighPerfEnclosure = c7kDellHighPerfEnclosure , threePar = threePar , sanSwitchExpansion = sanSwitchExpansion , sanSwitch = sanSwitch , 

      #clusterConfiguration
      sheetLabel	 =sheet['sheetLabel'],
      cpuOverProvisioning =sheet['cpuOverProvisioning'	],
      ramOverProvisioning =sheet['ramOverProvisioning'	],
      storageReservation =sheet['storageReservation'	],
      maxThroughputPerBladeOverprovisioning	=sheet['maxThroughputPerBladeOverprovisioning'	],
      maxRunningIOPSPerBladeOverprovisioning	 =sheet['maxRunningIOPSPerBladeOverprovisioning'	],
      bladeFlag	 = sheet['bladeFlag'	],
      enclosureFlag	 = sheet['enclosureFlag'	],
      probing	 = sheet['probing'	]
      )

def output_update_create(name):
   from django.conf import settings
   path = os.path.join(settings.MEDIA_ROOT, 'Fixed_property')
   file = os.path.join(path,'Output.xlsx')

   sheet_dic = {}
   multi_sheet_file = pd.ExcelFile(file)
   excel_sheet_names = multi_sheet_file.sheet_names
   for sheet in excel_sheet_names:
      df = pd.read_excel(multi_sheet_file, sheet_name=sheet)
      sheet_dic[sheet] = df
   #final_data = sheet_dic
   final_data = pickle.dumps(sheet_dic)
   print(type(final_data))
   
   master = output.objects.update_or_create(
   opco_name = 'OP9',
   data_center = 'DC9',
   user = 'xyz9',
   sheet = final_data
    )
'''While Quering the database for output this will be used.
queryset returns only one result this need to be handled.'''
# def download_from_db():
#    opco_name = 'OP9'
#    data_center = 'DC9'
#    user = 'xyz9'

#    queryset = output.objects.filter(opco_name=opco_name,data_center = data_center ,user = user).only('sheet')
#    opts = queryset.model._meta
#    model = queryset.model
#    response = HttpResponse(mimetype='text/csv')
#    # force download.
#    response['Content-Disposition'] = 'attachment;filename=export.csv'
#    # the csv writer
#    writer = csv.writer(response)
#    field_names = [field.name for field in opts.fields]
#    # Write a first row with header information
#    writer.writerow(field_names)
#    # Write data rows
#    for obj in queryset:
#       writer.writerow([getattr(obj, field) for field in field_names])
#    return response   
