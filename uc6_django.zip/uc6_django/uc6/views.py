from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.contrib import messages
from pandas.core.base import DataError
from uc6.src.bin.vf_blp import *
from sqlalchemy import create_engine
from django import forms
from .models import *
from django.conf import settings
from django.http import HttpResponse, Http404
from django.shortcuts import  render, redirect
from django import forms
from uc6.form import NewUserForm
from django.contrib.auth import login, authenticate,  logout 
from django.contrib.auth.forms import AuthenticationForm 
import string
import random
from pandas import ExcelWriter
import base64

import shutil
import re
import time
import os
from django.http import JsonResponse
import requests

#GCP bucket for ouput path
GCP_bucket_path = 'https://console.cloud.google.com/storage/browser/uc6-output/'
#GCP bucket for input fle temaplates
GCP_template_bucket = 'https://console.cloud.google.com/storage/browser/uc6-sample-template'


def random_string(string_length: int = 10) -> str:
    '''Generate a random string of fixed length '''
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(string_length))

'''Defination Views for each input separately'''
def home(request):
    context = {}
    reset_msg(request)
    return render(request, 'home.html', context)

def reset(request):
    # Reset the directory for a new user session
    reset_user(request)
    context = {}
    return render(request, 'home.html', context)

def vbom(request):
    media_root = ''
    user = ''
    executiontime = None
    context = {'sample_path': GCP_template_bucket}
    response = render(request, 'vbom.html', context)
    if request.method == "POST":
        if 'upload_vbom' in request.POST:
            if not(len(request.FILES) ==0):
                if not request.user.username == '':
                    user = request.user.username
                # if not 'user_id' in request.COOKIES.keys() or request.COOKIES['user_id'] == '':#if user is not there
                #     user=random_string(5) #create a user
                # else:
                    #user = request.COOKIES['user_id']#if user is already there fetch it
                media_root = os.path.join(settings.MEDIA_ROOT, user) #get user folder
                if not os.path.isdir(media_root):
                    create_user_folder(user) #create folder for user
                #form = vbomForm(request.POST)
                
                name, size_ext,encode_file = upload(request,user) #upload file to user folder
                #name, size_ext = upload(request,user) #upload file to user folder
                budget_cut_flag =request.POST.getlist('inputs')
                #budget cut code
                if budget_cut_flag and budget_cut_flag[0]== '1':
                    update_config("with_bc", True, user)
                
                max_host =request.POST.getlist('host')
                if max_host[0]:
                    update_config("max_hosts",int(max_host[0]),user)
                else:
                    update_config("max_hosts", 64, user)
                context['size'] = size_ext 
                context['url'] = name
                context['user_id'] = user
                update_config("excel", name, user)
                #add the encoded file
                update_config("excel_data", encode_file, user)
                template_name = 'vbom.html'
                response = render(request, template_name, context)
                response.set_cookie(key='user_id',value = user )
        elif 'run_script' in request.POST:
            if not request.user.username == '':
                user = request.user.username
            # if 'user_id' in request.COOKIES.keys():
            #     user = request.user.username
                #user = request.COOKIES['user_id']
            media_root = os.path.join(settings.MEDIA_ROOT, user)
            template_name = 'output.html'
            context['output_path'] = os.path.join(os.path.join(
                GCP_bucket_path, os.path.basename(media_root)), 'output')
            executiontime, Execption_list ,output_data= callMLScript(request, media_root)
            if not len(Execption_list) == 0:
                template_name = 'vbom.html'
            context['Time'] = executiontime
            response = render(request, template_name, context)
            response.set_cookie(key='user_id',value = user ) #set the same user to cookies
    return response

def cluster(request):
    jsonresponse = ''
    media_root = ''
    user = ''
    context = {}
    executiontime = None
    context = {'sample_path': GCP_template_bucket}
    response = render(request, 'cluster.html', context)
    if request.method == 'POST':
        if 'upload_cluster' in request.POST:
            if not(len(request.FILES) ==0):
                if not request.user.username == '':
                    user = request.user.username
                # if not 'user_id' in request.COOKIES.keys() or request.COOKIES['user_id'] == '':#if user is not there
                #     user = random_string(5) #create a user
                # else:
                #     user = request.COOKIES['user_id']
                media_root = os.path.join(settings.MEDIA_ROOT, user)
                if not os.path.isdir(media_root):
                    create_user_folder(user) #create folder for user
                
                name, size_ext,encode_file = upload(request,user)
                
                context['size'] = size_ext
                context['url'] = name
                context['user_id'] = user
                update_config("config", name, user)
                #upload the encoded file data
                update_config("config_data", encode_file, user)
                template_name = 'cluster.html'
                response = render(request, template_name, context)
                response.set_cookie(key='user_id',value = user )
        elif 'run_script' in request.POST:
            if not request.user.username == '':
                user = request.user.username
            # if 'user_id' in request.COOKIES.keys():
            #     user = request.COOKIES['user_id']
            media_root = os.path.join(settings.MEDIA_ROOT, user)
            template_name = 'output.html'
            context['output_path'] = os.path.join(os.path.join(GCP_bucket_path, os.path.basename(media_root)), 'output')
            executiontime, Execption_list,output_data = callMLScript(request, media_root)
            print(output_data)
            if not len(Execption_list) == 0:
                template_name = 'cluster.html'
            context['Time'] = executiontime
            context['To'] =  'output/'
            #response = redirect('output/')
            response = render(request, template_name, context)
            response.set_cookie(key='user_id',value = user )
            # response = jsonresponse
    return response

def catalog(request):
    media_root = ''
    user = ''
    context = {}
    executiontime = None
    response = render(request, 'catalog.html', context)
    
    if request.method == 'POST':
        if 'upload_catalog' in request.POST:
            if not(len(request.FILES) ==0):
                if not request.user.username == '':
                    user = request.user.username

                # if not 'user_id' in request.COOKIES.keys() or request.COOKIES['user_id'] == '':#if user is not there
                #     user=random_string(5) #create a user
                # else:
                #     user = request.COOKIES['user_id']#if user is already there fetch it
                media_root = os.path.join(settings.MEDIA_ROOT, user) #get user folder
                if not os.path.isdir(media_root):
                    create_user_folder(user) #create folder for user
                
                name, size_ext,encode_file = upload(request,user)
                context['size'] = size_ext
                context['url'] = name
                context['user_id'] = user
                update_config("catalog", name, user)
                #upload encoded data
                update_config("catalog_data", encode_file, user)
                template_name = 'catalog.html'
                response = render(request, template_name, context)
                response.set_cookie(key='user_id',value = user )
        elif 'run_script' in request.POST:
            if not request.user.username == '':
                user = request.user.username
            # if 'user_id' in request.COOKIES.keys():
            #     user = request.COOKIES['user_id']
            media_root = os.path.join(settings.MEDIA_ROOT, user)
            template_name = 'output.html'
            context['output_path'] = os.path.join(os.path.join(
                GCP_bucket_path, os.path.basename(media_root)), 'output')
            executiontime, Execption_list = callMLScript(request, media_root)
            if not len(Execption_list) == 0:
                template_name = 'catalog.html'
            context['Time'] = executiontime
            response = render(request, template_name, context)
            response.set_cookie(key='user_id',value = user )
    return response

def register_request(request):
    if request.method == "POST":
        reset_msg(request)
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful." )
            return redirect("home")
        messages.error(request, "Unsuccessful registration. Invalid information.")
    form = NewUserForm()
    return render (request=request, template_name="register.html", context={"register_form":form})

def login_request(request):
    if request.method == "POST":
        reset_msg(request)
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                return redirect("home")
            else:
                messages.error(request,"Invalid username or password.")
        else:
            messages.error(request,"Invalid username or password.")
    form = AuthenticationForm()
    return render(request=request, template_name="login.html", context={"login_form":form})

def logout_request(request):
    logout(request)
    reset_msg(request)
    messages.info(request, "You have successfully logged out.") 
    return redirect("login")
''' --------------------------------------------------------------- 
    other required methods  for 
    operations and small fuctionalities
'''
def reset_msg(request):
    storage = messages.get_messages(request)
    storage.used = True

def post( request):
    user = request.user.username
    # user = request.COOKIES['user_id']
    media_root = os.path.join(settings.MEDIA_ROOT, user)
    import json
    data = json.loads(open(os.path.join(media_root, 'greenfield_dataConfig.json')).read())
    data["message"]= "required parameters for ML"
    data  = json.dumps(data)
    print(data,type(data))
    r = requests.get('http://127.0.0.1:5000/', json = data)#params=data,
    if not r:
        raise Exception('No data fetched!')
    elif str(r.status_code) == '200':
        json = r.json()
        dict,vbom_name = decode_excel(json)
        writer = ExcelWriter(os.path.join( media_root,vbom_name), engine='openpyxl')

        for key,val in dict.items():
            print(key)
            val.to_excel(writer,index=False,sheet_name=key)
        writer.save()
        return {'sucess code: '+ str(r.status_code) : json },vbom_name
    else:
        return {'server side error: '+ str(r.status_code) : {} },'no output'
    #return JsonResponse(data, status=201)

''' --------------------------------------------------------------- 
    other required methods  for 
    operations and small fuctionalities
'''
def reset_msg(request):
    storage = messages.get_messages(request)
    storage.used = True
def callMLScript(request, media_root):
    executiontime = 'None'
    Execption_list = []
    res_json = {}
    if os.path.isdir(media_root):
        Execption_list = []
        file_list = [f for f in os.listdir(
            media_root)if os.path.isfile(os.path.join(media_root, f))]
        excel_file_no = [f for f in os.listdir(
            media_root) if re.search(r'.*\.(xlsx)$', f)]
        json_file_no = [f for f in os.listdir(
            media_root) if re.search(r'.*\.(json)$', f)]
        
        if len(excel_file_no) >= 2 and len(json_file_no) >= 2:
            start_time = time.time()
            try:
                res_json,vbom_name = post(request)
                if not res_json.values():
                    messages.error(request, 'Response Status:'+str(res_json.keys())+'But response data is empty')
            except Exception as e:
                messages.error(request, e)
                messages.error(request, 'ML Server server not found: Server Error (500)')
                Execption_list.append('ML Server server not found: Server Error (500)')

            end_time = time.time()
            executiontime = '%.2f' % ((end_time - start_time)/60) + ' minutes'
            #store database operations
            db_operations(request,media_root,'greenfield_dataConfig.json',vbom_name)
            # #output method
            output(request,vbom_name)
        else:
            messages.error(request, "Warning: Required input files are not uploaded!!!" +
                        "\n"+" Provided input are " + str(file_list))
            Execption_list.append("Warning: You haven't uploaded any file to process!!!")
        print('executiontime: ',executiontime)
    else:
        Execption_list.append("Warning: You haven't uploaded any file to process!!!")
        messages.error(request,"Warning: You haven't uploaded any file to process!!!")
    
    return executiontime, Execption_list
def db_operations(request,media_root,greenfield,vbom_name):
    j = json.loads(open(os.path.join(media_root,greenfield)).read())
    base = j['base']
    try:
        master_vbom_update_create(request,os.path.join(base,j['excel']))
    except Exception as e:
        print('exception in master_vbom db update')
    try:
        catalog_update_create(os.path.join(base,j['catalog']))
    except Exception as e:
        print('exception in catalog db update')
    try:
        cluster_update_create(os.path.join(base,j['config']))
    except Exception as e:
        print('exception in cluster db update')

def sizeOfFile(size):
    x = size
    y = 512000
    if x < y:
        value = round(x/1000, 2)
        ext = ' kb'
    elif x < y*1000:
        value = round(x/1000000, 2)
        ext = ' Mb'
    else:
        value = round(x/1000000000, 2)
        ext = ' Gb'
    return str(value)+ext

def upload(request,user):
    media_root = os.path.join(settings.MEDIA_ROOT, user)
    uploaded_file = request.FILES['document']
    try:
        os.remove(os.path.join(media_root,uploaded_file.name))
    except OSError:
        pass
    fs = FileSystemStorage(location=media_root)
    name = fs.save(uploaded_file.name, uploaded_file)
    size = fs.size(uploaded_file.name)
    size_ext = sizeOfFile(size)
    if uploaded_file.name.endswith(".json"):
        encode_file = encode_json(os.path.join(media_root,uploaded_file.name))
    else:
        encode_file = encode_excel(os.path.join(media_root,uploaded_file.name))
    return name, size_ext, encode_file

def encode_json(file_path):
    json_data = json.loads(open(file_path).read())
    str = json.dumps(json_data)
    return str
def encode_excel(file_path):
    dict ={}
    multi_sheet_file = pd.ExcelFile(file_path)
    excel_sheet_names = multi_sheet_file.sheet_names
    for sheet in excel_sheet_names:
        df = pd.read_excel(file_path,sheet_name=sheet,index_col=False,keep_default_na=True)
        dict[sheet] = df
    
    pickled = pickle.dumps(dict)
    import base64
    #So the 64encoded string is also a bytes-like string, but it doesn't contain the hex escape sequences so when it gets converted to a string, the string is still preserved when encoding it to bytes.
    pickled_b64 = base64.b64encode(pickled)
    #converting to string
    pickled_b64_str = pickled_b64.decode('utf-8')
    return pickled_b64_str

def decode_excel(json):
    vbom_str = ''
    vbom_name = ''
    for item in json.values():
        vbom_str = item
    for item1 in json.keys():
        vbom_name = item1
    pickled = base64.b64decode(vbom_str)
    dict = pickle.loads(pickled)
    return dict,vbom_name
def reset_user(request):
    if not request.user.username == '':
        user = request.user.username
    # if 'user_id' in request.COOKIES.keys() and not request.COOKIES['user_id'] == '':
    #     user = request.COOKIES['user_id']
        media_root = os.path.join(settings.MEDIA_ROOT, user)
        # update base path in greenfield
        if not media_root == settings.MEDIA_ROOT:
            shutil.rmtree(media_root, ignore_errors=True)
    reset_msg(request)
#  Note: download from the local directory 
#  as the execution process it very time taking uploading and downloading
#  the output from the DB will be very expensive, So keeping it to download
#  from the drectory for the user session
def output(request,vbom_name):
    # if not request.user.username == '':
    user = request.user.username
    # user = request.COOKIES['user_id']
    context = {}
    template_name = 'output.html'
    response = render(request, template_name, context)
    response.set_cookie(key='user_id',value = user )
    if request.method == 'GET':
        if 'download' in request.GET: 
            try:
                return download(request,user,vbom_name)
            except Exception as e:
                context['Error'] = e
    return render(request, template_name, context)
def download(request, user,vbom_name):
    file_path = os.path.join(os.path.join(settings.MEDIA_ROOT, user),vbom_name)
    # for f in os.listdir(file_path):
    #     file = f
    #     file_path = os.path.join(file_path,f)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/vnd.ms-excel")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404

def update_config(key, value, user):
    media_root = os.path.join(settings.MEDIA_ROOT, user)
    green_filed = os.path.join(os.path.join(
        media_root, 'greenfield_dataConfig.json'))
    json_file = json.loads(open(green_filed).read())
    if bool(json_file):# if the json file exist
        d = {key: value}  # set the key and value
        json_file.update(d)
        with open(green_filed, 'w') as f:
            json.dump(json_file, f)
    else:
        raise Exception(" Warning: The GreenField_DataConfig Json file is missing!!! ")

def create_user_folder(user):
    media_root = os.path.join(settings.MEDIA_ROOT, user)
    if not os.path.isdir(media_root):
        os.mkdir(media_root)
        time.sleep(2.0)  # to make sure the folder has been created
        mode = 0o777
        os.chmod(media_root, mode=mode)
    print("media_root: ", media_root, 'user_id: ', user)
    # copy the original greenfield to the new user folder
    static_input_path = os.path.join(settings.MEDIA_ROOT, 'Fixed_property')
    src_files = os.listdir(static_input_path)
    for file_name in src_files:
        full_file_name = os.path.join(static_input_path, file_name)
        if os.path.isfile(full_file_name):
            shutil.copy(full_file_name, media_root)
        else:
            raise Exception(" the file %d is missing." % full_file_name)
    update_config('base', media_root, user)
    # update_config('catalog', 'Catalog_Template_v2.1.xlsx', user)
    update_config('3par', '3PAR_Characterization-v1.2.xlsx', user)
    return media_root
