from django.test import TestCase
import MySQLdb
# print('here1')
# # Create your tests here.
# #internal ip  = 10.128.0.5
# # Connect to the MySQL database
# db = MySQLdb.connect(host = '10.164.0.59', user = 'admin', passwd = 'admin', db = 'uc6db')
# print('here')
# # Check if connection was successful
# if (db):
#     # Carry out normal procedure
#     print ("Connection successful")
# else:
# # Terminate
#     print ("Connection unsuccessful")
from .models import *
models.download_output()