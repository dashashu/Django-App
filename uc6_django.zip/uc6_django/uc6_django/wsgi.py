"""
WSGI config for uc6_django project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.1/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'uc6_django.settings')

#NOTE:
# for running on production server 
# comment line number 19 & 20 and uncomment line number 24
from dj_static import Cling
application = Cling(get_wsgi_application())

#NOTE: for running on django server
# uncomment the below line and comment line number 19 & 20
#application = get_wsgi_application() 

